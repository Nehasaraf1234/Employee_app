import React from "react";

class PropsInClassComponent extends React.Component{

    render(){

        return(

          <div className="PropsInClassComponent" style={{backgroundColor:"greenyellow"}}>

         <h1>Hello React with class Component</h1>
         <h2>Hello {this.props.name}</h2>
         <h3>Email:{this.props.email}</h3>
          </div>
        )
    }

}

export default PropsInClassComponent;