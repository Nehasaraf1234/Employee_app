from flask import Flask, request, jsonify
from flask_cors import CORS
import pyodbc

app = Flask(__name__)
CORS(app)

# Database connection
try:
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=localhost;'
        'DATABASE=employee_information;'
        'Trusted_Connection=yes;'
    )
    cursor = conn.cursor()
    print("Database connection successful")
except Exception as e:
    print(f"Error: {e}")
    conn = None
    cursor = None

@app.route('/add_employee', methods=['POST'])
def add_employee():
    data = request.get_json()

    # Basic validation
    required_fields = [
        'First_name', 'Middle_name', 'Last_name', 'Gender',
        'DOB', 'Mob_No', 'Aleternate_MonNo', 'EmailId',
        'MarriatialStatus', 'BloodGroup'
    ]

    for field in required_fields:
        if not data.get(field):
            return jsonify({"error": f"{field} is required"}), 400

    query = """
        INSERT INTO Employees (
            First_name, Middle_name, Last_name, Gender,
            DOB, Mob_No, Aleternate_MonNo, EmailId,
           MarriatialStatus, BloodGroup
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """

    values = (
        data.get('First_name'),
        data.get('Middle_name'),
        data.get('Last_name'),
        data.get('Gender'),
        data.get('DOB'),
        int(data.get('Mob_No')),
        int(data.get('Aleternate_MonNo')),
        data.get('EmailId'),
        data.get('MarriatialStatus'),
        data.get('BloodGroup')
    )

    try:
        cursor.execute(query, values)
        conn.commit()
        return jsonify({"message": "Employee added successfully"}), 200
    except Exception as e:
        print(e)
        return jsonify({"error": "Failed to add employee"}), 500

@app.route('/get_employees', methods=['GET'])
def get_employees():
    try:
        cursor.execute("SELECT * FROM Employees")
        rows = cursor.fetchall()
        columns = [column[0] for column in cursor.description]
        result = [dict(zip(columns, row)) for row in rows]
        return jsonify(result), 200
    except Exception as e:
        print(e)
        return jsonify({"error": "Failed to retrieve employees"}), 500




if __name__ == '__main__':
    app.run(debug=True)
