import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Employee() {
  const [formData, setFormData] = useState({
    First_name: '',
    Middle_name: '',
    Last_name: '',
    Gender: '',
    DOB: '',
    Mob_No: '',
    Aleternate_MonNo: '',
    EmailId: '',
    MarriatialStatus: '',
    BloodGroup: ''
  });

  const [employees, setEmployees] = useState([]);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
  e.preventDefault();

  // Ensure all fields are filled
  const values = Object.values(formData);
  if (values.some(val => val.trim() === '')) {
    alert("Please fill in all fields before submitting.");
    return;
  }

  try {
   const res = await axios.post('http://localhost:5000/add_employee', {
  ...formData,
  Mob_No: parseInt(formData.Mob_No),
  Alternate_MonNo: parseInt(formData.Alternate_MonNo)
});


    alert(res.data.message);
    setFormData({  
      First_name: '',
      Middle_name: '',
      Last_name: '',
      Gender: '',
      DOB: '',
      Mob_No: '',
      Aleternate_MonNo: '',
      EmailId: '',
      MarriatialStatus: '',
      BloodGroup: ''
    });

  
    handleView();
  } catch (err) {
    console.error(err);
    alert("Error submitting form");
  }
};

  const handleView = async () => {
    try {
      const res = await axios.get('http://localhost:5000/get_employees');
      setEmployees(res.data);
    } catch (err) {
      console.error(err);
      alert("Error fetching employees");
    }
  };

  const handleEdit = (employee) => {
    navigate('/manage', { state: { employee } });
  };

  return (
    <div className="Employee">
      <h1>Employee Management System</h1>
      <div className="Emp-data">
        <form id="myForm" onSubmit={handleSubmit}>
          <label>First Name</label>
          <input type="text" name="First_name" value={formData.First_name} onChange={handleChange} placeholder="Enter First Name" /><br />

          <label>Middle Name</label>
          <input type="text" name="Middle_name" value={formData.Middle_name} onChange={handleChange} placeholder="Enter Middle Name" /><br />

          <label>Last Name</label>
          <input type="text" name="Last_name" value={formData.Last_name} onChange={handleChange} placeholder="Enter Last Name" /><br />

          <label>Gender</label>
          <select name="Gender" value={formData.Gender} onChange={handleChange}>
            <option value="">Select Gender</option>
            <option value="Female">Female</option>
            <option value="Male">Male</option>
          </select><br />

          <label>Date of Birth</label>
          <input type="date" name="DOB" value={formData.DOB} onChange={handleChange} /><br />

          <label>Mobile Number</label>
          <input type="text" name="Mob_No" value={formData.Mob_No} onChange={handleChange} placeholder="Enter Mobile Number" /><br />

          <label>Alternate Mobile Number</label>
          <input type="text" name="Aleternate_MonNo" value={formData.Aleternate_MonNo} onChange={handleChange} placeholder="Enter Alternate Number" /><br />

          <label>Email ID</label>
          <input type="email" name="EmailId" value={formData.EmailId} onChange={handleChange} placeholder="Enter Email" /><br />

          <label>Marital Status</label>
          <select name="MarriatialStatus" value={formData.MarriatialStatus} onChange={handleChange}>
            <option value="">Select Marital Status</option>
            <option value="Married">Married</option>
            <option value="Single">Single</option>
          </select><br />

          <label>Blood Group</label>
          <select name="BloodGroup" value={formData.BloodGroup} onChange={handleChange}>
            <option value="">Select Blood Group</option>
            <option value="A+">A+</option>
            <option value="B+">B+</option>
            <option value="AB+">AB+</option>
            <option value="O+">O+</option>
            <option value="A-">A-</option>
            <option value="B-">B-</option>
            <option value="AB-">AB-</option>
            <option value="O-">O-</option>
          </select><br /><br />

          <button className='btn' type="submit">ADD</button>
          <button className='btn' type="button" onClick={handleView}>View</button>
        </form>
      </div>

      <div className="employee-list">
        <h2>Employee List</h2>
        {employees.length === 0 ? (
          <p>Currently No data is there to display</p>
        ) : (
          <table border="1">
            <thead>
              <tr>
                <th>First Name</th>
                <th>Middle Name</th>
                <th>Last Name</th>
                <th>Gender</th>
                <th>DOB</th>
                <th>Mobile No</th>
                <th>Alternate No</th>
                <th>Email</th>
                <th>Marital Status</th>
                <th>Blood Group</th>
                <th>Edit</th>
              </tr>
            </thead>
            <tbody>
              {employees.map((emp, index) => (
                <tr key={index}>
                  <td>{emp.First_name}</td>
                  <td>{emp.Middle_name}</td>
                  <td>{emp.Last_name}</td>
                  <td>{emp.Gender}</td>
                  <td>{emp.DOB}</td>
                  <td>{emp.Mob_No}</td>
                  <td>{emp.Aleternate_MonNo}</td>
                  <td>{emp.EmailId}</td>
                  <td>{emp.MarriatialStatus}</td>
                  <td>{emp.BloodGroup}</td>
                  <td>
                    <button onClick={() => handleEdit(emp)}>Show</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default Employee;
