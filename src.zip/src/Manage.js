import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

function Manage() {
  const location = useLocation();
  const navigate = useNavigate();
  const employee = location.state?.employee;

  const [isEditable, setIsEditable] = useState(false); // controls read-only state

  const [formData, setFormData] = useState({
    First_name: employee?.First_name || '',
    Middle_name: employee?.Middle_name || '',
    Last_name: employee?.Last_name || '',
    Gender: employee?.Gender || '',
    DOB: employee?.DOB || '',
    Mob_No: employee?.Mob_No || '',
    Alternate_MonNo: employee?.Alternate_MonNo || '',
    EmailId: employee?.EmailId || '',
    MarriatialStatus: employee?.MarriatialStatus || '',
    BloodGroup: employee?.BloodGroup || ''
  });

  const handleChange = (e) => {
    if (!isEditable) return;
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div>
      <h1>Employee Details</h1>
      {employee ? (
        <form>
          <label>First Name</label><br />
          <input
            type="text"
            name="First_name"
            value={formData.First_name}
            onChange={handleChange}
            readOnly={!isEditable}
          /><br />

          <label>Middle Name</label><br />
          <input
            type="text"
            name="Middle_name"
            value={formData.Middle_name}
            onChange={handleChange}
            readOnly={!isEditable}
          /><br />

          <label>Last Name</label><br />
          <input
            type="text"
            name="Last_name"
            value={formData.Last_name}
            onChange={handleChange}
            readOnly={!isEditable}
          /><br />

          <label>Gender</label><br />
          <input
            type="text"
            name="Gender"
            value={formData.Gender}
            onChange={handleChange}
            readOnly={!isEditable}
          /><br />

          <label>DOB</label><br />
          <input
            type="date"
            name="DOB"
            value={formData.DOB}
            onChange={handleChange}
            readOnly={!isEditable}
          /><br />

          <label>Mobile No</label><br />
          <input
            type="text"
            name="Mob_No"
            value={formData.Mob_No}
            onChange={handleChange}
            readOnly={!isEditable}
          /><br />

          <label>Alternate No</label><br />
          <input
            type="text"
            name="Alternate_MonNo"
            value={formData.Alternate_MonNo}
            onChange={handleChange}
            readOnly={!isEditable}
          /><br />

          <label>Email</label><br />
          <input
            type="email"
            name="EmailId"
            value={formData.EmailId}
            onChange={handleChange}
            readOnly={!isEditable}
          /><br />

          <label>Marital Status</label><br />
          <input
            type="text"
            name="MarriatialStatus"
            value={formData.MarriatialStatus}
            onChange={handleChange}
            readOnly={!isEditable}
          /><br />

          <label>Blood Group</label><br />
          <input
            type="text"
            name="BloodGroup"
            value={formData.BloodGroup}
            onChange={handleChange}
            readOnly={!isEditable}
          /><br /><br />

          <button type="button" onClick={() => setIsEditable(true)}>Edit</button>{' '}
          <button type="button" onClick={() => navigate('/')}>Back</button>
        </form>
      ) : (
        <p>No employee data found</p>
      )}
    </div>
  );
}

export default Manage;
