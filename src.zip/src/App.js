// App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Employee from './Employee';          
import Manage from './Manage';


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Employee />} />
        <Route path="/manage" element={<Manage />} />

        
      </Routes>
    </Router>
  );
}

export default App;
